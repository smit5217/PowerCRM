import React from "react";

function Shortcuts() {
  return (
    <div className="row mt-3">
      <div className="col-md-12 homepageCard">
        <div className="neumorphism-box p50 text-center">
          <h4>Shortcuts</h4>
        </div>
      </div>
    </div>
  );
}

export default Shortcuts;
