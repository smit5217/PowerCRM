import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import SelectionBox from "../Form/SelectionBox";
import { Link } from "react-router-dom";
import SelectSearch from "react-select-search";
import useFetch from "../../hooks/useFetch";

function GroupSiteForm(props) {
  const [formData, setFormData] = useState({
    gName: "",
    sites: "",
    gType: "",
  });
  // const [reqStatus, setReqStatus] = useState({
  //   isLoading: false,
  //   err: "",
  // });
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const [
    sendReqData,
    setSendReqData,
    reqStatus,
    responseData,
    setResponseData,
  ] = useFetch();
  const createGroupSite = function (e) {
    e.preventDefault();
    setMsg("");
    setErr("");
    let body = {
      group_name: formData.gName,
      group_type: formData.gType,
      sites: formData.sites,
    };
    setResponseData(null);
    setSendReqData({
      ...sendReqData,
      url: "multisite/",
      fetchObj: {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      },
      isAuthNeeded: true,
      expectStatusCode: [200, 201],
    });
  };

  useEffect(() => {
    if (responseData) {
      if (responseData.status === 200 || responseData.status === 201) {
        setMsg("Multisite Created Succesfully");
        setFormData({ gName: "", sites: "", gType: "" });
        props.setRefreshTable(true);
      } else {
        setErr("Some Problem Occured, Please try again");
      }
    }
  }, [responseData]);
  return (
    <div id="tabsSimple" className="col-xl-12 col-12 layout-spacing">
      <div className="neumorphism-box">
        <div className="statbox box box-shadow">
          <div className="widget-content widget-content-area">
            <Form onSubmit={createGroupSite}>
              <div className="row">
                <Form.Group className="mb-3 col-md-4" controlId="stuName">
                  <Form.Label>Group name</Form.Label>
                  <Form.Control
                    type="text"
                    name="stuName"
                    value={formData.gName}
                    onChange={(e) =>
                      setFormData((prev) => {
                        return { ...prev, gName: e.target.value };
                      })
                    }
                  />
                </Form.Group>
                <SelectionBox
                  groupClass="mb-3 col-md-4 selectbox"
                  groupId="parentCompany"
                  label="Sites"
                  multiple={true}
                  value={formData.sites}
                  onChange={(val) => {
                    console.log(val);
                    setFormData((prev) => {
                      return { ...prev, sites: val };
                    });
                  }}
                  name="parentCompany"
                  isSearch={true}
                  objKey="site_name"
                  url="sites/get/site/?brief=True"
                />
                <Form.Group
                  className={"mb-3 col-md-4 selectbox"}
                  controlId={"companyName"}
                >
                  <Form.Label className="text-center itsBlock">
                    Group type
                  </Form.Label>
                  <SelectSearch
                    options={[
                      { name: "Basic Site Group", value: "BASIC" },
                      { name: "Multi Site Group", value: "MULTI" },
                    ]}
                    placeholder={"Select Options"}
                    value={formData.gType}
                    onChange={(val) =>
                      setFormData((prev) => {
                        return { ...prev, gType: val };
                      })
                    }
                    name={"companyName"}
                  />
                </Form.Group>
                <div className="col-md-12 text-center">
                  {err?.length ? <p className="dengor">{reqStatus.err}</p> : ""}
                  {msg?.length ? <p className="">{reqStatus.msg}</p> : ""}
                  <Button
                    variant="primary"
                    type="submit"
                    disabled={reqStatus.isLoading}
                  >
                    {reqStatus.isLoading
                      ? "Creating Company"
                      : "Create Company"}
                  </Button>
                </div>
              </div>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GroupSiteForm;
