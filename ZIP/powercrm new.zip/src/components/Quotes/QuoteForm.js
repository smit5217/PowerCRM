import React, { useEffect, useReducer, useState } from "react";
import SelectionBox from "../Form/SelectionBox";
import { Button, Form } from "react-bootstrap";
import useFetch from "../../hooks/useFetch";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
const initialSiteState = {
  site: "",
  supplier: "",
  product: "",
  term: "",
  dayRate: "",
  nightRate: "",
  standingCharge: "",
  kvaCharge: "",
  additionalCharge: "",
  extraInfo: "",
  upLift: "",
  rateIncludedInUplift: false,
};
const QuoteReducer = (state, action) => {
  if (action?.all) {
    return action.data;
  }
  return { ...state, [action.type]: action.value };
};
function QuoteForm(props) {
  const [quoteForm, dispatchInputChange] = useReducer(
    QuoteReducer,
    initialSiteState
  );

  const [err, setErr] = useState("");

  const [
    sendcompanyData,
    setCompanyReqData,
    reqCompanyStatus,
    responsecompanyData,
    setCompanyResponseData,
    setStatus,
  ] = useFetch();
  const navigate = useNavigate();
  // const [
  //   companyGETData,
  //   setCompanyGETData,
  //   reqGetCompanyStatus,
  //   responseGetcompanyData,
  //   setCompanyGetResponseData,
  // ] = useFetch();
  const handleSelectionChange = function (type, value) {
    dispatchInputChange({ type, value });
  };

  const submitData = function (e) {
    e.preventDefault();
    let sendData = {
      additional_charge: quoteForm.additionalCharge,
      day_rate: quoteForm.dayRate,
      extra_info: quoteForm.extraInfo,
      kva_charge: quoteForm.kvaCharge,
      night_rate: quoteForm.nightRate,
      product: quoteForm.product,
      rates_already_include_at_uplift: quoteForm.rateIncludedInUplift,
      site: quoteForm.site,
      standing_charge: quoteForm.standingCharge,
      supplier: quoteForm.supplier,
      term: quoteForm.term,
      up_lift: quoteForm.upLift,
    };
    setCompanyResponseData();
    setCompanyReqData({
      ...sendcompanyData,
      url: `quote/generate-quote/`,
      fetchObj: {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(sendData),
      },
      isAuthNeeded: true,
      expectStatusCode: [200, 201],
    });
  };
  useEffect(() => {
    if (responsecompanyData) {
      if (
        responsecompanyData.status === 200 ||
        responsecompanyData.status === 201
      ) {
        navigate("/quotes");
      } else {
        setErr("Some Proble Occured, Please try again");
      }
    }
  }, [responsecompanyData]);
  return (
    <div class="container">
      <div className="row">
        <div className="neumorphism-box col-md-12 col-xl-12 col-12">
          <div className="widget-header">
            <h4>{props.title}</h4>
          </div>
          <Form onSubmit={submitData}>
            <SelectionBox
              groupClass="mb-3 col-md-6 selectbox"
              groupId="site"
              label="Site Name"
              value={quoteForm.site}
              onChange={handleSelectionChange.bind(null, "site")}
              name="site"
              isSearch={true}
              objKey="site_name"
              url="sites/get/site/?brief=True"
            />
            <Form.Group className="mb-3 col-12" controlId="supplier">
              <Form.Label>Supplier</Form.Label>
              <Form.Control
                type="text"
                name="supplier"
                value={quoteForm.supplier}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "supplier",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="product">
              <Form.Label>Product</Form.Label>
              <Form.Control
                type="text"
                name="product"
                value={quoteForm.product}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "product",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="term">
              <Form.Label>Term</Form.Label>
              <Form.Control
                type="text"
                name="term"
                value={quoteForm.term}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "term",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="dayRate">
              <Form.Label>Day Rate(pence/kwh)</Form.Label>
              <Form.Control
                type="text"
                name="dayRate"
                value={quoteForm.dayRate}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "dayRate",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="nightRate">
              <Form.Label>Night Rate(pence/kwh)</Form.Label>
              <Form.Control
                type="text"
                name="nightRate"
                value={quoteForm.nightRate}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "nightRate",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="standingCharge">
              <Form.Label>Standing Charge(pence)</Form.Label>
              <Form.Control
                type="text"
                name="standingCharge"
                value={quoteForm.standingCharge}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "standingCharge",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="kvaCharge">
              <Form.Label>KVA Charge(pence)</Form.Label>
              <Form.Control
                type="text"
                name="kvaCharge"
                value={quoteForm.kvaCharge}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "kvaCharge",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="name">
              <Form.Label>Additional Charge(£)</Form.Label>
              <Form.Control
                type="text"
                name="additionalCharge"
                value={quoteForm.additionalCharge}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "additionalCharge",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="extraInfo">
              <Form.Label>Extra Info</Form.Label>
              <Form.Control
                type="text"
                name="extraInfo"
                value={quoteForm.extraInfo}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "extraInfo",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="upLift">
              <Form.Label>Up Lift</Form.Label>
              <Form.Control
                type="text"
                name="upLift"
                value={quoteForm.upLift}
                onChange={(e) =>
                  dispatchInputChange({
                    type: "upLift",
                    value: e.target.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3 col-12" controlId="name">
              <Form.Check // prettier-ignore
                type="switch"
                id="custom-switch"
                label="Rates Already Include at uplift"
                checked={quoteForm.rateIncludedInUplift}
                onChange={(e) => {
                  dispatchInputChange({
                    type: "rateIncludedInUplift",
                    value: e.target.checked,
                  });
                }}
              />
            </Form.Group>{" "}
            <Button type="submit">
              {reqCompanyStatus.isLoading ? "Submitting" : "Submit"}
            </Button>
          </Form>
        </div>
      </div>
    </div>
  );
}

export default QuoteForm;
