import React from "react";

function RecentQuotations() {
  return (
    <div className="row">
      <div className="col-md-12 homepageCard">
        <div className="neumorphism-box p50 text-center">
          <h4>RecentQuotations</h4>
        </div>
      </div>
    </div>
  );
}

export default RecentQuotations;
