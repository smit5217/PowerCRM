import React from "react";
import QuoteForm from "../../components/Quotes/QuoteForm";

function AddQuote() {
  return <QuoteForm title="Add Quote" />;
}

export default AddQuote;
