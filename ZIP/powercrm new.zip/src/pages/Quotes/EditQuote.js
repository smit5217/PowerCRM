import React from "react";
import QuoteForm from "../../components/Quotes/QuoteForm";

function EditQuote() {
  return <QuoteForm />;
}

export default EditQuote;
