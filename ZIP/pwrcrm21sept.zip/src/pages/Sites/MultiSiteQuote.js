import React from "react";

function MultiSiteQuote() {
  return <div>MultiSiteQuote</div>;
}

export default MultiSiteQuote;
