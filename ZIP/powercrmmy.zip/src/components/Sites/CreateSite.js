import React, { useEffect, useReducer, useState } from "react";
import { Button, Form } from "react-bootstrap";
import SelectionBox from "../Form/SelectionBox";
import useFetch from "../../hooks/useFetch";
import useUiAction from "../../hooks/useUiAction";
import { uiAction } from "../../store/uiStore";
import { useDispatch } from "react-redux";

const initialSiteDetails = {
  parentCompany: "",
  siteName: "",
  companyName: "",
  typeOfOwner: "",
  ownerName: "",
  currentGasElectDetails: "",
};

const reducerSite = (state, action) => {
  return { ...state, [action.type]: action.value };
};
function CreateSite(props) {
  // state and reducers
  const [siteData, dispatchSiteData] = useReducer(
    reducerSite,
    initialSiteDetails
  );
  const [err, setErr] = useState("");

  // store dispatch
  const dispatch = useDispatch();

  //   custom hook for ajax calls
  const [
    sendReqData,
    setSendReqData,
    reqStatus,
    responseData,
    setResponseData,
  ] = useFetch();

  // for selectionbox value
  const handleChange = (fileName, file) => {
    // console.log(fileName, file);
    dispatchSiteData({ type: fileName, value: file });
  };

  // create site
  const createSite = async function (e) {
    e.preventDefault();
    if (
      !siteData.parentCompany?.length ||
      !siteData.siteName?.length ||
      !siteData.companyName ||
      !siteData.typeOfOwner?.length ||
      !siteData.ownerName?.length ||
      !siteData.currentGasElectDetails?.length
    ) {
      setErr("All Fields are Mandatory Please fill all the fields...");
      return;
    } else if (err?.length) {
      setErr("");
    }
    let body = {
      parent_company: siteData.parentCompany,
      site_name: siteData.siteName,
      company: siteData.companyName,
      type_of_owner: siteData.typeOfOwner,
      owner_name: siteData.ownerName,
      current_gas_and_electricity_supplier_details:
        siteData.currentGasElectDetails,
    };
    setSendReqData({
      ...sendReqData,
      url: "create/site",
      fetchObj: {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      },
      isAuthNeeded: true,
      expectStatusCode: [200, 201],
    });
  };

  // when we get response lets close the modal and show them success msg
  useEffect(() => {
    if (responseData) {
      dispatch(
        uiAction.setNotification({
          show: true,
          heading: "Site",
          msg: `${siteData.siteName} Site Created`,
        })
      );
      props.refreshTable(true);
      props.hideModal();
    }
  }, [responseData]);

  return (
    <div id="tabsSimple" className="col-xl-12 col-12 layout-spacing">
      <div className="neumorphism-box">
        <div className="statbox box box-shadow">
          <div className="widget-content widget-content-area">
            <Form onSubmit={createSite}>
              <div className="row">
                <Form.Group className="mb-3 col-md-6" controlId="stuName">
                  <Form.Label>Parent Company</Form.Label>
                  <Form.Control
                    type="text"
                    name="stuName"
                    value={siteData.parentCompany}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "parentCompany",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3 col-md-6" controlId="stuName">
                  <Form.Label>Site Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="stuName"
                    value={siteData.siteName}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "siteName",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <SelectionBox
                  groupClass="mb-3 col-md-6 selectbox"
                  groupId="companyName"
                  label="Company Name"
                  value={siteData.companyName}
                  onChange={handleChange.bind(null, "companyName")}
                  name="companyName"
                  isSearch={true}
                  objKey="name"
                  url="sites/get/company_name/"
                />

                <Form.Group className="mb-3 col-md-6" controlId="stuName">
                  <Form.Label>Type Of Owner</Form.Label>
                  <Form.Control
                    type="text"
                    name="stuName"
                    value={siteData.typeOfOwner}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "typeOfOwner",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3 col-md-6" controlId="stuName">
                  <Form.Label>Owner Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="stuName"
                    value={siteData.ownerName}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "ownerName",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3 col-md-6" controlId="stuName">
                  <Form.Label>
                    Current gas and electricity supplier details
                  </Form.Label>
                  <Form.Control
                    type="text"
                    name="stuName"
                    value={siteData.currentGasElectDetails}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "currentGasElectDetails",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <div className="col-md-12 text-center">
                  {err?.length ? <p className="dengor">{err}</p> : ""}
                  <Button
                    variant="primary"
                    type="submit"
                    disabled={reqStatus.isLoading}
                  >
                    {reqStatus.isLoading ? "Creating Site" : "Create Site"}
                  </Button>
                </div>
              </div>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CreateSite;
