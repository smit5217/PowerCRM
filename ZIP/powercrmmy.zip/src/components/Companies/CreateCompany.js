import React, { useEffect, useReducer, useState } from "react";

import { uiAction } from "../../store/uiStore";
import useFetch from "../../hooks/useFetch";
import { useDispatch } from "react-redux";
import SelectionBox from "../Form/SelectionBox";
import { Button, Form } from "react-bootstrap";
const initialSiteDetails = {
  name: "",
  number_of_employees: "",
  registration_no: "",
  estimated_turnover: "",
  account_name: "",
  bank_name: "",
  account_no: "",
  shortcode: "",
};

const reducerSite = (state, action) => {
  return { ...state, [action.type]: action.value };
};
function CreateCompany(props) {
  // state and reducers
  const [siteData, dispatchSiteData] = useReducer(
    reducerSite,
    initialSiteDetails
  );
  const [err, setErr] = useState("");

  // store dispatch
  const dispatch = useDispatch();

  //   custom hook for ajax calls
  const [
    sendReqData,
    setSendReqData,
    reqStatus,
    responseData,
    setResponseData,
  ] = useFetch();

  // for selectionbox value
  const handleChange = (fileName, file) => {
    // console.log(fileName, file);
    dispatchSiteData({ type: fileName, value: file });
  };

  // create site
  const createCompany = async function (e) {
    e.preventDefault();
    if (
      !siteData.name?.length ||
      !siteData.number_of_employees?.length ||
      !siteData.registration_no?.length ||
      !siteData.estimated_turnover?.length ||
      !siteData.account_name?.length ||
      !siteData.bank_name?.length ||
      !siteData.account_no?.length ||
      !siteData.shortcode?.length
    ) {
      setErr("All Fields are Mandatory Please fill all the fields...");
      return;
    } else if (err?.length) {
      setErr("");
    }

    setSendReqData({
      ...sendReqData,
      url: "company/",
      fetchObj: {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(siteData),
      },
      isAuthNeeded: true,
      expectStatusCode: [200, 201],
    });
  };

  // when we get response lets close the modal and show them success msg
  useEffect(() => {
    if (responseData) {
      dispatch(
        uiAction.setNotification({
          show: true,
          heading: "Company",
          msg: `${siteData.name} Company  Created`,
        })
      );
      props.refreshTable(true);
      props.hideModal();
    }
  }, [responseData]);
  return (
    <div id="tabsSimple" className="col-xl-12 col-12 layout-spacing">
      <div className="neumorphism-box">
        <div className="statbox box box-shadow">
          <div className="widget-content widget-content-area">
            <Form onSubmit={createCompany}>
              <div className="row">
                <Form.Group className="mb-3 col-md-6" controlId="name">
                  <Form.Label>Name Of Company</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={siteData.name}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "name",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group
                  className="mb-3 col-md-6"
                  controlId="number_of_employees"
                >
                  <Form.Label>Number Of Employees</Form.Label>
                  <Form.Control
                    type="number"
                    name="number_of_employees"
                    value={siteData.number_of_employees}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "number_of_employees",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>

                <Form.Group
                  className="mb-3 col-md-6"
                  controlId="registration_no"
                >
                  <Form.Label>Registration Number</Form.Label>
                  <Form.Control
                    type="text"
                    name="registration_no"
                    value={siteData.registration_no}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "registration_no",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group
                  className="mb-3 col-md-6"
                  controlId="estimated_turnover"
                >
                  <Form.Label>Estimated Turnover</Form.Label>
                  <Form.Control
                    type="number"
                    name="estimated_turnover"
                    value={siteData.estimated_turnover}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "estimated_turnover",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3 col-md-6" controlId="account_name">
                  <Form.Label>Account Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="account_name"
                    value={siteData.account_name}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "account_name",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3 col-md-6" controlId="bank_name">
                  <Form.Label>Bank Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="bank_name"
                    value={siteData.bank_name}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "bank_name",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3 col-md-6" controlId="account_no">
                  <Form.Label>Account Number</Form.Label>
                  <Form.Control
                    type="text"
                    name="account_no"
                    value={siteData.account_no}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "account_no",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3 col-md-6" controlId="shortcode">
                  <Form.Label>Shortcode</Form.Label>
                  <Form.Control
                    type="text"
                    name="shortcode"
                    value={siteData.shortcode}
                    onChange={(e) =>
                      dispatchSiteData({
                        type: "shortcode",
                        value: e.target.value,
                      })
                    }
                  />
                </Form.Group>

                <div className="col-md-12 text-center">
                  {err?.length ? <p className="dengor">{err}</p> : ""}
                  <Button
                    variant="primary"
                    type="submit"
                    disabled={reqStatus.isLoading}
                  >
                    {reqStatus.isLoading
                      ? "Creating Company"
                      : "Create Company"}
                  </Button>
                </div>
              </div>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CreateCompany;
