import React from "react";

function EditCompany() {
  return <div>EditCompany</div>;
}

export default EditCompany;
