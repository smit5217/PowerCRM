import React from "react";

function EditQuote() {
  return <div>EditQuote</div>;
}

export default EditQuote;
