import React from "react";

function AddQuote() {
  return <div>AddQuote</div>;
}

export default AddQuote;
