import React from "react";
import GroupQuoteForm from "../../components/Group Quote/GroupQuoteForm";

function AddGroupQuote() {
  return <GroupQuoteForm title="Add Quote" isEdit={false} />;
}

export default AddGroupQuote;
