import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { NavLink, useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import uiAction from "../../../store/uiStore";
import CollapsableComponent from "../CollapsableComponent";
import enqSvg from "../../../assets/img/enquiry.svg";
import { authAction } from "../../../store/authStore";
import { deleteFromLocalStorage } from "../../../helpers/helperFunctions";
import { Button, Container, Nav, Navbar } from "react-bootstrap";

export default function NavBar(props) {
  const uiData = useSelector((state) => state.uiStore);
  const dispatch = useDispatch();
  const locaton = useLocation();
  const navigate = useNavigate();
  const logout = () => {
    dispatch(
      authAction.setAuthStatus({
        userName: "",
        loggedIn: false,
        accessToken: null,
        refreshToken: null,
        userId: null,
        user_type: null,
        timeOfLogin: null,
        logInOperation: -1,
      })
    );
    deleteFromLocalStorage("loginInfo");
    navigate(`/login`);
  };
  return (
    <>
      {" "}
      <Navbar bg="light" data-bs-theme="light">
        <Container>
          <Navbar.Brand href="#home" className="mx-4">
            PowerCRM
          </Navbar.Brand>
          <Navbar className="justify-content-end">
            <Nav className="me-auto">
              <Nav.Link as={NavLink} to="/">
                Dashboard
              </Nav.Link>
              <Nav.Link as={NavLink} to="/companies">
                Company
              </Nav.Link>
              <Nav.Link as={NavLink} to="/sites">
                Sites
              </Nav.Link>
              <Nav.Link as={NavLink} to="/group-sites">
                Group Sites
              </Nav.Link>
              <Nav.Link as={NavLink} to="/quotes">
                Quotes
              </Nav.Link>
              <Nav.Link as={Button} onClick={logout}>
                Logout
              </Nav.Link>
            </Nav>
          </Navbar>
        </Container>
      </Navbar>
    </>
  );
}
